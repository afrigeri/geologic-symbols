These svg patterns are produced and maintained by Daven Quinn.  Data has been cloned from Daven git repository: https://github.com/davenquinn/geologic-patterns

The patterns have been contributed by USGS personell.

